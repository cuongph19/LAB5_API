const express = require('express');

const router = express.Router();

module.exports = router;

router.get('/', (req, res) => {
    res.send('vao api mobile');
});

const server = require('./server');

const uri = 'mongodb://localhost:27017/LAB5_API';

const spModel = require('./productModel');
const mongoose = require('mongoose');

router.get('/list', async (req, res) => {
    await mongoose.connect(uri);

    let Products = await spModel.find();

    console.log(Products);

    res.send(Products);
});