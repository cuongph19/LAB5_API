const express = require('express');

const app = express();

const port = 3030;

const bodyParser = require("body-parser");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


app.listen(port, () => {
    console.log(`Server dang chay cong ${port}`)
})

const api = require('./api');
app.use ('/api', api);

const uri = 'mongodb://localhost:27017/LAB5_API';
const mongoose = require('mongoose');
const productModel = require("./productModel");

app.get('/', async (req, res)=>{
    await mongoose.connect(uri);

    let Products = await productModel.find();

    console.log(Products);

    res.send(Products);
})

app.get('/delete/:id', async (req, res) => {
    try {
        await mongoose.connect(uri);
        let id = req.params.id;
        console.log(id);
        await productModel.deleteOne({ _id: id });
        res.redirect('../');
    } catch (error) {
        console.error(error);
        res.json({error:error});
    }
});
app.put('/update/:_id', async (req, res) => {
    try {
        const _id = req.params._id;
        const { name } = req.body; // Lấy dữ liệu nhập từ React Native, loại bỏ trường id
        const updateProduct = await productModel.findByIdAndUpdate(_id, { name }, { new: true });
        console.log(updateProduct);
        res.json(updateProduct);
    } catch (error) {
        console.error(error);
        res.json({ error: error });
    }
});

app.post('/add', async (req, res) => {
    try {
        const { name } = req.body; // Lấy dữ liệu nhập từ React Native, loại bỏ trường id
        const addProduct = new productModel({ name}); // Tạo đối tượng mới với dữ liệu mà người dùng nhập vào
        await addProduct.save(); // Lưu sản phẩm vào cơ sở dữ liệu
        console.log(addProduct);
        res.json(addProduct);
    } catch (error) {
        console.error(error);
        res.json({ error: error });
    }
});
app.get('/api/search', async (req, res) => {
    try {
        const keyword = req.query.keyword; // Lấy từ khóa tìm kiếm từ query parameters
        await mongoose.connect(uri); // Kết nối đến cơ sở dữ liệu
        // Tìm kiếm sản phẩm có tên chứa từ khóa tìm kiếm
        const products = await productModel.find({ name: { $regex: keyword, $options: 'i' } });
        res.json(products); // Trả về kết quả tìm kiếm
    } catch (error) {
        console.error(error);
        res.json({ error: error });
    }
});