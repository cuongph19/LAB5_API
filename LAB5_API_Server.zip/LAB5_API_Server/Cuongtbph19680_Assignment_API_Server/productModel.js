const mongoose = require('mongoose');

const ProductSchema = mongoose.Schema({

    name: {
        type: String,
        required: true
    },

 
});

const productModel = mongoose.model('Product', ProductSchema);

module.exports = productModel;